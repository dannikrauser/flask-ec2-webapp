import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, send_file, flash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "users.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2MB

def init_db():
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            firstname TEXT,
            lastname TEXT,
            email TEXT,
            address TEXT,
            file_path TEXT
        )
        """)
        conn.commit()

def get_user(username):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ?", (username,))
        return c.fetchone()

def word_count_from_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        words = [w for w in text.split() if w.strip()]
        return len(words)
    except Exception:
        return None

@app.route("/")
def register_page():
    return render_template("register.html")

@app.route("/register", methods=["POST"])
def register():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()

    if not username or not password:
        flash("Username and password are required.")
        return redirect(url_for("register_page"))

    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
        session["username"] = username
        return redirect(url_for("details_page"))
    except sqlite3.IntegrityError:
        flash("That username already exists.")
        return redirect(url_for("register_page"))

@app.route("/details")
def details_page():
    if "username" not in session:
        return redirect(url_for("login_page"))
    return render_template("details.html")

@app.route("/details", methods=["POST"])
def save_details():
    if "username" not in session:
        return redirect(url_for("login_page"))

    username = session["username"]
    firstname = request.form.get("firstname", "").strip()
    lastname = request.form.get("lastname", "").strip()
    email = request.form.get("email", "").strip()
    address = request.form.get("address", "").strip()

    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("""
            UPDATE users
            SET firstname=?, lastname=?, email=?, address=?
            WHERE username=?
        """, (firstname, lastname, email, address, username))
        conn.commit()

    return redirect(url_for("profile", username=username))

@app.route("/profile/<username>")
def profile(username):
    user = get_user(username)
    if user is None:
        return "User not found", 404

    wc = None
    if user["file_path"]:
        wc = word_count_from_file(user["file_path"])

    return render_template("profile.html", user=user, word_count=wc)

@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()

    user = get_user(username)
    if user is None or user["password"] != password:
        flash("Invalid username or password.")
        return redirect(url_for("login_page"))

    session["username"] = username
    return redirect(url_for("profile", username=username))

@app.route("/upload", methods=["POST"])
def upload():
    if "username" not in session:
        return redirect(url_for("login_page"))

    username = session["username"]
    user = get_user(username)
    if user is None:
        return "User not found", 404

    if "file" not in request.files:
        flash("No file provided.")
        return redirect(url_for("profile", username=username))

    f = request.files["file"]
    if f.filename == "":
        flash("No file selected.")
        return redirect(url_for("profile", username=username))

    if not f.filename.lower().endswith(".txt"):
        flash("Please upload a .txt file (Limerick.txt).")
        return redirect(url_for("profile", username=username))

    save_path = os.path.join(UPLOAD_DIR, f"{username}_Limerick.txt")
    f.save(save_path)

    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("UPDATE users SET file_path=? WHERE username=?", (save_path, username))
        conn.commit()

    return redirect(url_for("profile", username=username))

@app.route("/download/<username>")
def download(username):
    user = get_user(username)
    if user is None or not user["file_path"]:
        return "No file found.", 404
    return send_file(user["file_path"], as_attachment=True, download_name="Limerick.txt")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login_page"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)

